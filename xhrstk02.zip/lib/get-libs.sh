#!/bin/bash  
# Extract library files
wget -qO- -O temp.zip http://www.stud.fit.vutbr.cz/~xpeska03/resources.zip --header "Referer: www.stud.fit.vutbr.cz" && unzip -o temp.zip && rm temp.zip
