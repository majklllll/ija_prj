# ija_prj
Projekt do IJA

Překlad:
	ant compile

Spuštění:
	ant run
